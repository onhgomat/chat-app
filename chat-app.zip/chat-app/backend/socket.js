
module.exports = (io) => {
  const users = {};

  io.on('connection', socket => {
    socket.on('join', ({ username, room }) => {
      socket.join(room);
      users[socket.id] = { username, room };
      socket.to(room).emit('message', `${username} joined the chat`);
    });

    socket.on('message', msg => {
      const { username, room } = users[socket.id];
      io.to(room).emit('message', `${username}: ${msg}`);
    });

    socket.on('media', data => {
      const { room } = users[socket.id];
      socket.to(room).emit('media', data);
    });

    socket.on('disconnect', () => {
      const user = users[socket.id];
      if (user) {
        socket.to(user.room).emit('message', `${user.username} left`);
        delete users[socket.id];
      }
    });
  });
};
