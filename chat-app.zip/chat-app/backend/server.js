
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const path = require('path');
const cors = require('cors');
const fs = require('fs');
const bcrypt = require('bcrypt');

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

const usersPath = path.join(__dirname, 'users.json');
let users = fs.existsSync(usersPath) ? require(usersPath) : {};

function isPasswordUsed(pwd) {
  return Object.values(users).some(user => bcrypt.compareSync(pwd, user.hash));
}

app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  if (users[username]) return res.status(400).send('Username already exists.');
  if (isPasswordUsed(password)) return res.status(400).send('Password already used.');
  const hash = await bcrypt.hash(password, 10);
  users[username] = { username, hash };
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
  res.send('Signup successful!');
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = users[username];
  if (!user) return res.status(400).send('User not found.');
  const match = await bcrypt.compare(password, user.hash);
  if (!match) return res.status(401).send('Incorrect password.');
  res.send('Login successful!');
});

require('./socket')(io);

const PORT = 3000;
http.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
